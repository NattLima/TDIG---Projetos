import React from "react";

function Sobre() {
  return (
    <div>
      <h1>Sobre</h1>
      <p>Esta é a página sobre.</p>
    </div>
  );
}

export default Sobre;
